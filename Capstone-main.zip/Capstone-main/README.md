
AI Pre/Post Call System
=======================

Contents:
- backend/: FastAPI backend (includes your original uploaded files capstone1.ipynb and finalcode4.py)
- frontend/: Minimal React + Vite app (calls the backend at http://localhost:8000)

Quickstart (backend):
1. Set your OpenAI API key in env:
   export OPENAI_API_KEY="<your_key>"
2. Build & run with docker-compose:
   docker-compose up --build
   (or run locally)
   cd backend
   pip install -r requirements.txt
   uvicorn app:app --reload

Quickstart (frontend):
cd frontend
npm install
npm run dev

Notes:
- The project includes your original files: capstone1.ipynb and finalcode4.py in the root.
- Pre-Call supports PDF only.
- The backend wrapper modules (precall_module.py and postcall_module.py) implement the API wrappers.
- Make sure you have enough resources for Whisper if using Docker (torch + whisper model download).
