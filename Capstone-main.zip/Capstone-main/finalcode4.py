# Auto-generated script from notebook: finalcode4.ipynb

# You can import functions from this module in adapters.



# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session

!pip install -q openai-whisper torch librosa soundfile jiwer openai

import whisper
import torch
import re
import os
from openai import OpenAI, OpenAIError

# ============================================================
# SET YOUR OPENAI API KEY HERE
# ============================================================
os.environ["OPENAI_API_KEY"] = ""
client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

# ============================================================
# STEP 1: Transcription using Whisper
# ============================================================
audio_path = "/kaggle/input/capstone234/capstone.mp3"
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using device: {device}")


model = whisper.load_model("small", device=device)
print(" Whisper model loaded successfully.")

print(f"\nTranscribing: {os.path.basename(audio_path)} ...")
result = model.transcribe(audio_path)
transcript = result["text"].strip()
print("\n=== FULL TRANSCRIPTION ===\n")
print(transcript)

# --- Clean transcript ---
def clean_text(text):
    text = text.lower().strip()
    text = re.sub(r'[^a-z0-9\s]', '', text)
    text = re.sub(r'\s+', ' ', text)
    return text

call_transcript = clean_text(transcript)

# ============================================================
# STEP 2: Audit Rubric
# ============================================================
audit_rubric = """
You are an HR performance evaluator.
Evaluate the employee's communication during this customer interaction using:
1. Empathy (1–10)
2. Factual Accuracy (1–10)
3. De-escalation (1–10)
4. Professionalism (1–10)

Give short, concrete feedback with one example.
"""

# ============================================================
# STEP 3: Gen–Eval Loop (lightweight)
# ============================================================
def gpt_generate_feedback(transcript, rubric, critique=None):
    """Generate concise HR feedback using GPT-4o-mini (cheap & fast)."""
    try:
        prompt = f"""
Transcript:
\"\"\"{transcript}\"\"\"

Rubric:
{rubric}

Previous Critique: {critique or 'None'}

Give numeric scores (1–10) and 2–3 lines of feedback with one clear example.
"""
        response = client.chat.completions.create(
            model="gpt-4o-mini",   
            messages=[
                {"role": "system", "content": "You are a precise HR evaluator."},
                {"role": "user", "content": prompt},
            ],
            temperature=0.3,
            max_tokens=400
        )
        return response.choices[0].message.content.strip()

    except OpenAIError as e:
        print(f"\nLLM request failed: {e}")
        return "(Offline fallback) Employee showed good accuracy and professionalism but can improve empathy."

def gpt_evaluate_quality(feedback_text):
    """Critique the feedback quality (cheap evaluator)."""
    try:
        critique_prompt = f"""
Does the feedback contain numeric scores (1–10), one example, and one improvement tip?
Answer only 'OK' if yes, else say what's missing.

Feedback:
\"\"\"{feedback_text}\"\"\"
"""
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",   
            messages=[
                {"role": "system", "content": "You are a concise quality evaluator."},
                {"role": "user", "content": critique_prompt},
            ],
            temperature=0,
            max_tokens=100
        )
        return response.choices[0].message.content.strip()

    except OpenAIError:
        return "OK"

def run_gen_eval_loop(transcript, rubric, max_tries=3):
    critique = ""
    latest_feedback = ""

    for i in range(max_tries):
        print(f"\n--- LOOP ITERATION {i+1} ---")
        latest_feedback = gpt_generate_feedback(transcript, rubric, critique)
        print(f"\nGenerator Output (Draft {i+1}):\n{latest_feedback}")

        critique = gpt_evaluate_quality(latest_feedback)
        print(f"\nEvaluator Response: {critique}")

        if critique.strip().upper() == "OK":
            print("--- Feedback is high quality. Breaking loop. ---")
            break
        else:
            print("--- Refining feedback further... ---")

    return latest_feedback

# Run LLM-powered Gen–Eval loop
final_audit_report = run_gen_eval_loop(call_transcript, audit_rubric)
print("\n=== FINAL VERIFIED AUDIT REPORT ===")
print(final_audit_report)

# ============================================================
# STEP 4: Handle MULTIPLE Questions about Employee Performance
# ============================================================
print("\n=== EMPLOYEE PERFORMANCE Q&A MODE ===")
print("Enter multiple questions (type 'done' when finished):")

questions = []
while True:
    q = input("Question: ").strip()
    if q.lower() == "done" or q == "":
        break
    questions.append(q)

if not questions:
    print("\nNo questions entered.")
else:
    print(f"\nYou asked {len(questions)} questions. Analyzing...\n")

    # Combine all questions into a single LLM prompt
    joined_questions = "\n".join([f"{i+1}. {q}" for i, q in enumerate(questions)])

    multi_prompt = f"""
Transcript:
\"\"\"{transcript}\"\"\"

Audit Report:
{final_audit_report}

Questions:
{joined_questions}

Please answer each question separately and clearly, referencing the transcript and audit where helpful.
Keep answers brief and professional.
"""

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",  
            messages=[
                {"role": "system", "content": "You are a concise HR and communication evaluator."},
                {"role": "user", "content": multi_prompt},
            ],
            temperature=0.3,
            max_tokens=500  
        )
        llm_response = response.choices[0].message.content.strip()

    except OpenAIError as e:
        llm_response = f"(Offline fallback) The employee performed well overall. Error: {e}"

    print("\n=== MULTI-QUESTION PERFORMANCE ANALYSIS ===\n")
    print(llm_response)
