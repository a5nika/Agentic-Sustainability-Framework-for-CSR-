import React, { useState } from "react";
import axios from "axios";

export default function PostCall() {
  const [file, setFile] = useState(null);
  const [transcript, setTranscript] = useState("");
  const [feedback, setFeedback] = useState("");

  const uploadAudio = async () => {
    if (!file) return alert("Please select an audio file first.");
    const formData = new FormData();
    formData.append("file", file);
    const res = await axios.post("http://localhost:8000/upload-audio", formData);
    setTranscript(res.data.transcript);
  };

  const evaluate = async () => {
    const formData = new FormData();
    formData.append("transcript", transcript);
    const res = await axios.post("http://localhost:8000/evaluate", formData);
    setFeedback(res.data.feedback);
  };

  return (
    <div style={{ display: "flex", justifyContent: "space-between", gap: "30px" }}>
      {/* Transcript Section */}
      <div style={{ width: "48%" }}>
        <h3>Upload Audio</h3>
        <input type="file" accept="audio/mp3" onChange={(e) => setFile(e.target.files[0])} />
        <button onClick={uploadAudio}>Upload Audio</button>
        <textarea
          rows="18"
          value={transcript}
          readOnly
          placeholder="Transcript will appear here..."
        />
      </div>

      {/* Feedback Section */}
      <div style={{ width: "48%" }}>
        <h3>Feedback</h3>
        <button onClick={evaluate}>Run Evaluation</button>
        <textarea
          rows="18"
          value={feedback}
          readOnly
          placeholder="Feedback will appear here..."
        />
      </div>
    </div>
  );
}
