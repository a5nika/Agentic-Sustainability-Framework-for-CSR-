import React, { useState } from "react";
import PreCall from "./PreCall";
import PostCall from "./PostCall";
import "./styles.css";

export default function App() {
  const [activeTab, setActiveTab] = useState("pre");

  return (
    <div className="container">
      <h1 style={{ textAlign: "center", marginBottom: "20px", color: "#00ADB5" }}>
        AI Pre/Post Call Dashboard
      </h1>
      <div className="tab-buttons">
        <button
          className={activeTab === "pre" ? "active" : ""}
          onClick={() => setActiveTab("pre")}
        >
          Pre-Call
        </button>
        <button
          className={activeTab === "post" ? "active" : ""}
          onClick={() => setActiveTab("post")}
        >
          Post-Call
        </button>
      </div>
      {activeTab === "pre" ? <PreCall /> : <PostCall />}
    </div>
  );
}
