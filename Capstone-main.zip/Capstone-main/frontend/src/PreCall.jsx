import React, { useState } from "react";
import axios from "axios";

function ChatBubble({ type, text }) {
  const isUser = type === "user";
  return (
    <div
      style={{
        display: "flex",
        justifyContent: isUser ? "flex-end" : "flex-start",
        marginBottom: "10px",
      }}
    >
      <div
        style={{
          backgroundColor: isUser ? "#00ADB5" : "#393E46",
          color: "#FFF",
          padding: "12px 16px",
          borderRadius: "12px",
          maxWidth: "70%",
        }}
      >
        {text}
      </div>
    </div>
  );
}

export default function PreCall() {
  const [file, setFile] = useState(null);
  const [documentText, setDocumentText] = useState("");
  const [question, setQuestion] = useState("");
  const [chat, setChat] = useState([]);

  const uploadPDF = async () => {
    if (!file) return alert("Please select a PDF file first.");
    const formData = new FormData();
    formData.append("file", file);
    const res = await axios.post("http://localhost:8000/upload-doc", formData);
    setDocumentText(res.data.document_text);
  };

  const askQuestion = async () => {
    if (!question.trim()) return;
    const userMsg = { type: "user", text: question };
    setChat([...chat, userMsg]);

    const formData = new FormData();
    formData.append("question", question);
    formData.append("document_text", documentText);

    setQuestion("");

    const res = await axios.post("http://localhost:8000/ask", formData);
    const botMsg = { type: "bot", text: res.data.answer };
    setChat([...chat, userMsg, botMsg]);
  };

  return (
    <div style={{ display: "flex", justifyContent: "space-between", gap: "30px" }}>
      {/* Left side - PDF text */}
      <div style={{ width: "50%" }}>
        <h3>Upload PDF</h3>
        <input type="file" accept="application/pdf" onChange={(e) => setFile(e.target.files[0])} />
        <button onClick={uploadPDF}>Upload PDF</button>
        <textarea
          rows="20"
          value={documentText}
          readOnly
          placeholder="Extracted text will appear here..."
        />
      </div>

      {/* Right side - Chat UI */}
      <div style={{ width: "50%", display: "flex", flexDirection: "column" }}>
        <h3>Ask Questions</h3>
        <div
          style={{
            backgroundColor: "#1E2A38",
            padding: "15px",
            borderRadius: "10px",
            height: "400px",
            overflowY: "auto",
            marginBottom: "10px",
          }}
        >
          {chat.map((msg, i) => (
            <ChatBubble key={i} type={msg.type} text={msg.text} />
          ))}
        </div>
        <div style={{ display: "flex", gap: "10px" }}>
          <input
            type="text"
            placeholder="Ask a question..."
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
          />
          <button onClick={askQuestion}>Ask</button>
        </div>
      </div>
    </div>
  );
}
