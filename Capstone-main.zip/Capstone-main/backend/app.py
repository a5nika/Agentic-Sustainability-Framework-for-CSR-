from fastapi import FastAPI, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
import shutil
import os
from precall_module import extract_text_from_pdf, generate_doc_answer
from postcall_module import transcribe_audio, evaluate_call_feedback

app = FastAPI()

# Enable frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.get("/")
def home():
    return {"status": "AI Pre/Post Call System Backend Running"}

# ---------------- PRE-CALL ----------------
@app.post("/upload-doc")
async def upload_pdf(file: UploadFile):
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    text = extract_text_from_pdf(file_path)
    return {"document_text": text}

@app.post("/ask")
async def ask_question(question: str = Form(...), document_text: str = Form(...)):
    answer = generate_doc_answer(document_text, question)
    return {"answer": answer}

# ---------------- POST-CALL ----------------
@app.post("/upload-audio")
async def upload_audio(file: UploadFile):
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    transcript = transcribe_audio(file_path)
    return {"transcript": transcript}

@app.post("/evaluate")
async def evaluate(transcript: str = Form(...)):
    feedback = evaluate_call_feedback(transcript)
    return {"feedback": feedback}
