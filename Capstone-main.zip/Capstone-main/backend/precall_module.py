import os
import re
import glob
import tempfile
from sentence_transformers import SentenceTransformer
import faiss
from pdf2image import convert_from_path
import pytesseract
import google.generativeai as genai

# Configure Gemini properly
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

CHUNK_SIZE = 1500
OVERLAP = 200
TOP_K = 2
LLM_MAX_TOKENS = 200

# ---------------- Gemini generator ----------------
def gemini_generator(prompt, max_new_tokens=LLM_MAX_TOKENS, temperature=0):
    try:
        model = genai.GenerativeModel("gemini-2.5-flash")
        response = model.generate_content(prompt)
        return response.text.strip() if response.text else "(No response)"
    except Exception as e:
        return f"(Gemini error) {e}"

def classify_query_meta(query):
    prompt = f"Classify the following query as either 'company' or 'general':\n\n{query}\nAnswer:"
    text = gemini_generator(prompt, max_new_tokens=50, temperature=0)
    if "company" in text.lower():
        return "company"
    return "general"

def smart_chunk_text(text: str, chunk_size=CHUNK_SIZE, overlap=OVERLAP):
    if not text:
        return []
    sentences = re.split(r'(?<=[\.\?\!])\s+', text)
    chunks, current = [], ""
    for sent in sentences:
        if len(current) + len(sent) + 1 <= chunk_size:
            current = (current + " " + sent).strip()
        else:
            if current:
                chunks.append(current)
            current = sent
    if current:
        chunks.append(current)
    return chunks

def clean_ocr_text(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def load_and_chunk_pdfs_simple(folder_path):
    all_chunks = []
    from pypdf import PdfReader
    for file_path in glob.glob(os.path.join(folder_path, "*.pdf")):
        basename = os.path.basename(file_path)
        reader = PdfReader(file_path)
        for page_index, page in enumerate(reader.pages, start=1):
            text = page.extract_text() or ""
            if text.strip():
                for c in smart_chunk_text(text):
                    all_chunks.append({"content": c, "metadata": {"source": basename, "page": page_index}})
    return all_chunks

def load_and_chunk_pdfs(folder_path):
    all_chunks = []
    for file_path in glob.glob(os.path.join(folder_path, "*.pdf")):
        basename = os.path.basename(file_path)
        pages = convert_from_path(file_path, dpi=200)
        for page_index, page_image in enumerate(pages, start=1):
            raw_text = pytesseract.image_to_string(page_image, lang='eng')
            page_text = clean_ocr_text(raw_text)
            if page_text:
                for c in smart_chunk_text(page_text):
                    all_chunks.append({"content": c, "metadata": {"source": basename, "page": page_index}})
    return all_chunks

def load_and_chunk_pdfs_combined(folder_path):
    return load_and_chunk_pdfs(folder_path) + load_and_chunk_pdfs_simple(folder_path)

def create_faiss_index(chunks):
    embedder = SentenceTransformer('all-MiniLM-L6-v2')
    texts = [chunk['content'] for chunk in chunks]
    embeddings = embedder.encode(texts, show_progress_bar=False, convert_to_numpy=True)
    faiss.normalize_L2(embeddings)
    index = faiss.IndexFlatIP(embeddings.shape[1])
    index.add(embeddings)
    metadata = [chunk['metadata'] for chunk in chunks]
    return embedder, index, texts, metadata

def generate_answer_from_context(query, retrieved_documents_with_meta):
    formatted = []
    for doc, meta in retrieved_documents_with_meta:
        src, pg = meta.get("source", "unknown"), meta.get("page", "unknown")
        formatted.append(f"[{src} | page:{pg}]\n{doc}")
    context_block = "\n\n---\n\n".join(formatted)
    prompt = f"""Use ONLY the provided context to answer the question.
If not enough info, reply "not enough information".

Context:
{context_block}

Question:
{query}

Answer:"""
    return gemini_generator(prompt)

def answer_query_faiss(embedder, index, contents, metadata, query, top_k=TOP_K):
    query_embedding = embedder.encode([query], convert_to_numpy=True)
    faiss.normalize_L2(query_embedding)
    D, I = index.search(query_embedding, top_k)
    retrieved_chunks = [(contents[i], metadata[i]) for i in I[0]]
    return generate_answer_from_context(query, retrieved_chunks)

def route_query(query, embedder, index, contents, metadata):
    label = classify_query_meta(query)
    if label == "company":
        return answer_query_faiss(embedder, index, contents, metadata, query)
    else:
        return gemini_generator(query)

def extract_text_from_pdf(pdf_path: str) -> str:
    try:
        temp_folder = tempfile.mkdtemp()
        os.makedirs(temp_folder, exist_ok=True)
        os.system(f'cp "{pdf_path}" "{temp_folder}"')
        chunks = load_and_chunk_pdfs_combined(temp_folder)
        return "\n\n".join([c["content"] for c in chunks])
    except Exception as e:
        return f"(PDF extraction error) {e}"

def generate_doc_answer(document_text: str, question: str) -> str:
    try:
        chunks = smart_chunk_text(document_text)
        embedder, index, texts, meta = create_faiss_index(
            [{"content": c, "metadata": {"source": "uploaded_doc"}} for c in chunks]
        )
        answer = route_query(question, embedder, index, texts, meta)
        return answer or "(No answer generated)"
    except Exception as e:
        return f"(RAG error) {e}"
