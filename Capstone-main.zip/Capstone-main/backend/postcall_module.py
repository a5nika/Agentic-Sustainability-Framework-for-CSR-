import os
import re
import torch
import whisper

USE_GENAI = bool(os.getenv("GOOGLE_API_KEY"))
if USE_GENAI:
    import google.generativeai as genai
    genai.configure(api_key=os.getenv("GOOGLE_API_KEY", ""))
else:
    from openai import OpenAI
    client_openai = OpenAI(api_key=os.getenv("OPENAI_API_KEY", ""))

def clean_text(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r'[^a-z0-9\s]', '', text)
    text = re.sub(r'\s+', ' ', text)
    return text

def transcribe_audio(audio_path: str) -> str:
    device = "cuda" if torch.cuda.is_available() else "cpu"
    try:
        model = whisper.load_model("small", device=device)
    except Exception as e:
        return f"(Whisper error) {e}"
    result = model.transcribe(audio_path)
    transcript = result.get("text", "").strip()
    return clean_text(transcript)

audit_rubric = """
You are an HR performance evaluator.
Evaluate the employee's communication using:
1. Empathy (1–10)
2. Factual Accuracy (1–10)
3. De-escalation (1–10)
4. Professionalism (1–10)
"""

def _call_llm_for_feedback(prompt: str):
    if USE_GENAI:
        model = genai.GenerativeModel("gemini-2.5-flash")
        resp = model.generate_content(prompt)
        return resp.text.strip() if getattr(resp, "text", None) else "(No response)"
    else:
        resp = client_openai.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a precise HR evaluator."},
                {"role": "user", "content": prompt}
            ]
        )
        return resp.choices[0].message.content.strip()

def run_gen_eval_loop(transcript: str, rubric: str = audit_rubric):
    feedback_prompt = f"""
Transcript:
\"\"\"{transcript}\"\"\"

Rubric:
{rubric}

Give numeric scores (1–10) and 2–3 lines of feedback with one example.
"""
    return _call_llm_for_feedback(feedback_prompt)

# ---------- Wrapper for FastAPI ----------
def evaluate_call_feedback(transcript: str) -> str:
    try:
        feedback = run_gen_eval_loop(transcript)
        return feedback
    except Exception as e:
        return f"(Evaluation error) {e}"
